<!-- Services Section -->
<section id="product" class="services section ">
  <div class="container">
    <div class="row gy-4">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-4 col">
          <div class="card" style="border:1px solid #3fbbc0">
            <img src="<?php echo e($product->picture ? asset('storage/'.$product->picture) : asset('assets/user/img/doctors/doctors-3.jpg')); ?>" class="card-img-top" alt="..." style="height:200px;width:100%!important;object-fit: cover;background:gainsboro">
            <div class="card-body" style="border-top:1px solid #3fbbc0">
              <h5 class="card-title"><?php echo e(substr($product->name ,0,15 )); ?>...</h5>
              <p class="card-text" style="font-size:14px"><?php echo e(substr($product->description,0,50)); ?>...</p>
              <a href="<?php echo e(route('product.item',['id'=>$product->id])); ?>" style="background-color: #3fbbc0;font-size:14px;padding:5px 7px;color:#fff;" class="btn stretched-link" style="font-size:14px">See Detail</a>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

</section><!-- /Services Section --><?php /**PATH C:\Users\Link-Up Technology\Desktop\linkup_bdColour\resources\views/user/home/service2.blade.php ENDPATH**/ ?>