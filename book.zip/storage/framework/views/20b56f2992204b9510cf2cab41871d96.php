<?php $__env->startSection('title'); ?>
    home page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

    <style>
        .bg-breadcrumb {
            position: relative;
            overflow: hidden;
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(<?php echo e(asset('assets/user/img/carousel-1.jpg')); ?>);
            background-position: center center;
            background-repeat: no-repeat;
            background-size: cover;
            padding: 20px 0 27px 0;
        }
        .table-striped>thead>tr>th {
            background-color: #3fbbc0;
            color: #fff;
            font-size: 16px;
        }
        .table-striped>tbody>tr>td {
            font-size: 14px;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagenave'); ?>
    <?php echo $__env->make('user.layout.navbar',['page'=>'dealerlist'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <main class="main">
        <div class="container-fluid bg-breadcrumb">
            <div class="bg-breadcrumb-single"></div>
            <div class="container text-center py-3" style="max-width: 900px;">
                <h1 class="text-white  mb-4 wow fadeInDown" data-wow-delay="0.1s"
                    style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInDown;">Dealer List</h1>
                <ol class="breadcrumb justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInDown;">
                    <li class="breadcrumb-item text-white"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="breadcrumb-item active text-primary">Dealers</li>
                </ol>
            </div>
        </div>
        <!-- Service Details Section -->
        <section id="" class="service-details section">
            <!-- col-lg-2 -->
            <div class="container">
                <div class="row mb-1">
                    <div class="col-md-4 col-sm-6  offset-md-8 offset-sm-6 d-flex justify-content-end">
                        <form class="w-100">
                            <div class="input-group mb-0">
                                <input type="text" style="font-size:14px" style="font-size:10px" name="search"
                                    value="<?php echo e(request()->query('search')); ?>" placeholder="Search By Name"
                                    class="form-control p-0 ps-2 w-75">
                                <span class="input-group-text "><a href="<?php echo e(route('delearlist')); ?>" class="">
                                        <!-- <i class="fas fa-trash"></i> -->
                                        X
                                    </a></span>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <table class="table table-striped shadow">
                            <thead>
                                <tr>
                                    <th>SL No:</th>
                                    <th>Name</th>
                                    <th>Org. Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Area</th>
                                    <th>Address</th>
                                    <th>Website</th>

                                </tr>

                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $allDelears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($delear->name); ?></td>
                                        <td><?php echo e($delear->company_name); ?></td>
                                        <td><?php echo e($delear->phone); ?></td>
                                        <td><?php echo e($delear->email); ?></td>
                                        <td><?php echo e($delear->area->name); ?></td>
                                        <td><?php echo e($delear->address); ?></td>
                                        <td>
                                            <?php if($delear->website): ?>
                                                <a href="<?php echo e($delear->website); ?>" target="_blank" style="font-size:20px"><i
                                                        class="bi bi-link-45deg"></i></a>
                                            <?php else: ?>
                                                Not Found
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                    <div class="col-12">
                        <div class="d-flex justify-content-center">
                            <?php if($allDelears->previousPageUrl()): ?>
                                <a href="<?php echo e($allDelears->previousPageUrl()); ?>" class="btn btn-success mx-3 border-0"
                                    style="background:#3fbbc0"><i class="fas fa-hand-point-left"></i></a>
                            <?php endif; ?>

                            <?php if($allDelears->nextPageUrl()): ?>
                                <a href="<?php echo e($allDelears->nextPageUrl()); ?>" class="btn btn-success border-0"
                                    style="background:#3fbbc0"><i class="fas fa-hand-point-right "></i></a>
                            <?php endif; ?>


                        </div>
                    </div>
                </div>


            </div>
        </section><!-- /Service Details Section -->
    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Corporate_website\linkup_bdColour\resources\views/user/delearlist.blade.php ENDPATH**/ ?>