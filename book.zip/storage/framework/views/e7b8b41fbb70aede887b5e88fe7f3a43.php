<!-- About Section -->
<section id="about" class="about section light-background">

  <!-- Section Title -->
  <div class="container section-title" data-aos="fade-up">
    <h2>About Us<br></h2>
    <div class="container">
      <div class="row gy-4">
        <div class="col-lg-6 position-relative align-self-start" data-aos="fade-up" data-aos-delay="100">
          <img
            src="<?php echo e(($about && $about->picture) ? asset('storage/' . $about->picture) : asset('assets/user/img/about.jpg')); ?>"
            class="img-fluid" alt="">
        </div>
        <div class="col-lg-6 content d-flex flex-column justify-content-between" data-aos="fade-up"
          data-aos-delay="200">
          <div style="text-align:start">
            <h3><?php echo e($about->title ?? 'Title Will Be Hare'); ?></h3>
            <p class="fst-italic" style="text-align:start!important;">
              <?php echo ($about && $about->about) ? \Illuminate\Support\Str::words($about->about, 80, '...') : ""; ?>

            </p>
          </div>
          <div class="d-flex justify-content-end align-self-end">
            <a href="<?php echo e(route('company')); ?>" class="btn"
              style="background: #1cadb3b8;font-size:14px;color:#fff;width:100px">Read More</a>
          </div>
        </div>
      </div>
    </div>
</section><!-- /About Section --><?php /**PATH C:\Users\Link-Up Technology\Desktop\linkup_bdColour\resources\views/user/home/about.blade.php ENDPATH**/ ?>