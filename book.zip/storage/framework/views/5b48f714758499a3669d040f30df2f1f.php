<section id="featured-services" class="featured-services section">
  <div class="container">
    <div class="swiper mySwiper">
      <div class="swiper-wrapper">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="swiper-slide">
            <div class="service-item position-relative" style="padding:0px;margin:0px;border:3px solid #3fbbc0">
              <div class="bg-dark">
                <img src="<?php echo e(($category->img ) ? asset('storage/'.$category->img) : asset('assets/user/img/cat2.jpg')); ?>" alt="" class="img-fluid" width="100%">
              </div>
              <div class="p-3">
                <h4><a href="" class="stretched-link"><?php echo e($category->name); ?></a></h4>
                <p><?php echo e(substr($category->description, 0, 100)); ?></p>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</section>
<?php /**PATH C:\Users\Link-Up Technology\Desktop\linkup_bdColour\resources\views/user/home/editservice.blade.php ENDPATH**/ ?>