<?php $__env->startSection('title', 'Admin Page'); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .table > tbody > tr > td{
            padding: 0px !important;
            margin-bottom: 2px;
        }
        .iconsize{
            font-size: 15px;
        }
        .profileImg{
            width: auto;
            height: 100px; 
            object-fit: cover;
            border: 2px dashed #ccc;
            border-radius: 6px;
        }
        .tablepicture{
            width: 30px;
            height: 30px;
            object-fit: fill;
        }
         .headbg > tr > th{
            background-color: #3c5236;
            color: #fff;
            padding: 2px !important;
            margin-bottom: 2px;
        }

        .productimages {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }
    .preview-img {
        position: relative;
        display: inline-block;
    }
    .preview-img img {
        width: 70px;
        height: 70px;
        object-fit: cover;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    .preview-img .remove-btn {
        position: absolute;
        top: -5px;
        right: -5px;
        background: red;
        color: white;
        border: none;
        border-radius: 50%;
        width: 20px;
        height: 20px;
        font-size: 12px;
        cursor: pointer;
    }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageside'); ?>
      <?php echo $__env->make('admin.layout.sidebar', ['page' => 'product'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bodyContent'); ?>
    <div class="container">
        <div class="page-inner">
            <div class="card mb-1">
                <div class="card-header pt-1 pb-0">
                    <h4 class="text-center">Create Product</h4>
                </div>
                <form method="post" id="productForm" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body p-3 ">
                        <div class="row">
                            <div class="col-md-6 col-12">
                                <div class="row mb-2">
                                    <div class="col-md-3 col-12">
                                        <div class="">
                                            <label for="email2">Name :</label>
                                        </div>
                                    </div>
                                    <div class="col-md-9 col-12">
                                        <input type="text" class="form-control p-1 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="name" value="<?php echo e(old('name',optional($editItem)->name)); ?>"
                                            placeholder="Enter Product Name">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <div class="col-md-3 col-12">
                                        <div class="">
                                            <label for="email2">Price :</label>

                                        </div>
                                    </div>
                                    <div class="col-md-9 col-12">
                                        <input type="text" class="form-control p-1 <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="price" value="<?php echo e(old('price',optional($editItem)->price)); ?>"
                                            placeholder="Enter Product Price">
                                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <div class="col-md-3 col-12">
                                        <div class="">
                                            <label for="description">Discription :</label>

                                        </div>
                                    </div>
                                    <div class="col-md-9 col-12">
                                        <textarea name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2" id=""><?php echo e(old('description', optional($editItem)->description)); ?></textarea>
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <div class="row mb-2">
                                    <div class="col-md-3 col-12">
                                        <div class="">
                                            <label for="email2">Catagory :</label>

                                        </div>
                                    </div>
                                    <div class="col-md-9 col-12">
                                        <select name="category_id" id="" class="form-control p-1 <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <!-- <option value="1">dkslk</option>
                                            <option value="1">dkslk</option> -->
                                            <option value="">-- Select Category --</option>
                                            <?php if($editItem != null): ?>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>" <?php if(old('category_id', optional($editItem)->category_id) == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>

                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>" <?php if((old('category_id') == $category->id)): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php endif; ?>

                                        </select>
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-md-12 col-12 d-flex justify-content-center mt-1">
                                                    <label for="imageInput" style="cursor: pointer;">
                                                        <!-- (placeholder) -->
                                                        <img id="previewImage" 
                                                            src="<?php echo e(($editItem && $editItem->picture) ? asset('storage/' . $editItem->picture) : asset('assets/admin/img/demoUpload.jpg')); ?>" 
                                                            alt="Demo Image" 
                                                            class="profileImg"
                                                            style="">
                                                    </label>

                                                    <!-- hidden input -->
                                                    <input type="file" name="picture" id="imageInput" accept="image/*" style="display: none;">
                                                </div>
                                                <?php $__errorArgs = ['picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="text-danger text-center"><?php echo e($message); ?></p>
                                                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                    <div class="">
                                        <label for="long_Description">Long Discription :</label>
                                        <textarea name="logn_description" class="form-control" rows="6" id="description"><?php echo e(old('logn_description',optional($editItem)->logn_description)); ?></textarea>
                                    </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end mt-3">
                           <input type="submit" value="Submit" class="btn btn-primary me-3 p-2">
                        </div>
                    </div>
                </form>
            </div>


            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header p-2">
                            <h5 class="card-title ">ALL Product</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <div id="basic-datatables_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">
                                    <div class="row">

                                        <div class="col-sm-12 col-md-6 offset-md-6">
                                            <div id="basic-datatables_filter" class="dataTables_filter">
                                                <label class="d-flex justify-content-end">Search:
                                                    <form>

                                                        <input type="search" value="<?php echo e(request()->query('search')); ?>" name="search" class="form-control form-control-sm"
                                                            placeholder="" aria-controls="basic-datatables">
                                                    </form>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="basic-datatables"
                                                class="display table table-striped table-hover dataTable" role="grid"
                                                aria-describedby="basic-datatables_info">
                                                <thead class="headbg">
                                                    <tr role="row bg-dark" >
                                                        <th style="width: 136.031px;">SL NO:</th>
                                                        <th style="width: 35.875px;">Image</th>
                                                        <th style="width: 214.469px;">Name</th>
                                                        <th style="width: 214.469px;">Description</th>
                                                        <th style="width: 214.469px;">Price</th>
                                                        <th style="width: 101.219px;">Category</th>

                                                        <th style="width: 81.375px;">Action</th>
                                                    </tr>
                                                </thead>

                                                <tbody>

                                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr role="row" class="odd" >
                                                        <td class="sorting_1"><?php echo e($loop->iteration); ?></td>
                                                        <td>
                                                            <a href="">
                                                                <img class="tablepicture" src="<?php echo e($product->picture ? asset('storage/' . $product->picture) : asset('assets/admin/img/demoProfile.png')); ?>" alt="user profile picture">
                                                            </a>
                                                        </td>
                                                        <td><?php echo e($product->name); ?></td>
                                                        <td><?php echo e(substr($product->description, 0, 50)); ?>...</td>
                                                        <td><?php echo e($product->price); ?></td>

                                                        <td><?php echo e($product->category->name); ?></td>

                                                        <td class="d-flex justify-content-center">

                                                            <a href="<?php echo e(route('admin.product', ['id' => $product->id, 'page' => request()->query('page'), 'search' => request()->query('search')])); ?>" class="btn btn-info p-1 me-1">
                                                                <i class="fas fa-edit iconsize"></i>
                                                            </a>

                                                            <form action="<?php echo e(route('admin.product.delete', ['id' => $product->id])); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <!-- <input type="submit" value="Delete"> -->
                                                                 <button type="submit" class="btn btn-danger p-1"><i class="fas fa-trash-alt iconsize"></i></button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <p>there is no users</p>

                                                <?php endif; ?>



                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                   <div class="row">
                                        <div class="col-12 d-flex justify-content-end me-2">
                                            <?php if($products->previousPageUrl()): ?>
                                                <a href="<?php echo e($products->previousPageUrl()); ?>"
                                                    class="btn btn-primary mx-2 p-1"><i class="fas fa-hand-point-left"></i></a>
                                            <?php endif; ?>

                                            <?php if($products->nextPageUrl()): ?>
                                                <a href="<?php echo e($products->nextPageUrl()); ?>" class="btn btn-primary mx-2 p-1"><i
                                                        class="fas fa-hand-point-right "></i></a>
                                            <?php endif; ?>

                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/36.0.1/classic/ckeditor.js"></script>
    <script>



        const imageInput = document.getElementById('imageInput');
        const previewImage = document.getElementById('previewImage');

        imageInput.addEventListener('change', function () {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();

                reader.onload = function (e) {
                    previewImage.src = e.target.result;
                };

                reader.readAsDataURL(file);
            }
        })


        

       class MyUploadAdapter {
        constructor(loader) {
            this.loader = loader;
        }

        upload() {
            return this.loader.file
                .then(file => new Promise((resolve, reject) => {
                    const formData = new FormData();
                    formData.append('upload', file);

                    fetch("<?php echo e(route('upload.description.image')); ?>", {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: formData
                    })
                        .then(res => res.json())
                        .then(res => {
                            resolve({ default: res.url });
                        })
                        .catch(err => {
                            reject(err);
                        });
                }));
        }

        abort() {
            // abort logic if needed
        }
    }

    function MyCustomUploadAdapterPlugin(editor) {
        editor.plugins.get('FileRepository').createUploadAdapter = (loader) => {
            return new MyUploadAdapter(loader);
        };
    }

    ClassicEditor
        .create(document.querySelector('#description'), {
            extraPlugins: [MyCustomUploadAdapterPlugin]
        })
        .catch(error => {
            console.error('CKEditor Error:', error);
        });





    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Corporate_website\linkup_bdColour\resources\views/admin/productView.blade.php ENDPATH**/ ?>