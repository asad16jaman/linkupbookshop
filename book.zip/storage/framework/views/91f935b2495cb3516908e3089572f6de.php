<!-- Doctors Section -->
    <section id="management" class="doctors section light-background">
      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Managemen</h2>
      </div><!-- End Section Title -->
      <div class="container">
        <div class="row gy-4">
          <?php $__currentLoopData = $managements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $management): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 col-12 d-flex justify-content-around align-items-stretch" data-aos="fade-up" data-aos-delay="100">
              <div class="team-member">
                <div class="member-img">
                  <img src="<?php echo e(asset('storage/'.$management->photo )); ?>" style="width: 262px; height: 210px; object-fit: contain" class="img-fluid" alt="">
                </div>
                <div class="member-info">
                  <h4 class="text-center"><?php echo e($management->name); ?></h4>
                  <span class="text-center"><?php echo e($management->designation); ?></span>
                </div>
              </div>
            </div><!-- End Team Member -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section><!-- /Doctors Section --><?php /**PATH C:\Users\Link-Up Technology\Desktop\linkup_bdColour\resources\views/user/home/managemen.blade.php ENDPATH**/ ?>