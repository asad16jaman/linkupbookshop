 <!-- Hero Section -->
    <section id="hero" class="hero section" style="padding:0px!important">

      <div id="hero-carousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">
        <?php $__currentLoopData = $carousels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carousel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="carousel-item <?php echo e($loop->first ? 'active' : ""); ?>">
          <img src="<?php echo e(asset('storage/'.$carousel->img)); ?>" alt="" class="c_img">
        </div><!-- End Carousel Item -->
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a class="carousel-control-prev" href="#hero-carousel" role="button" data-bs-slide="prev">
          <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
        </a>

        <a class="carousel-control-next" href="#hero-carousel" role="button" data-bs-slide="next">
          <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
        </a>

        <ol class="carousel-indicators"></ol>

      </div>

    </section><!-- /Hero Section --><?php /**PATH C:\Users\Link-Up Technology\Desktop\linkup_bdColour\resources\views/user/home/carousel.blade.php ENDPATH**/ ?>