<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta
      content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
      name="viewport"
    />
    <link
      rel="icon"
      href="<?php echo e(asset('assets/admin/img/titleicon.svg')); ?>" 
      type="image/x-icon"
    />

    <!-- Fonts and icons -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/webfont/webfont.min.js')); ?>"></script>
    <script>
      WebFont.load({
        google: { families: ["Public Sans:300,400,500,600,700"] },
        custom: {
          families: [
            "Font Awesome 5 Solid",
            "Font Awesome 5 Regular",
            "Font Awesome 5 Brands",
            "simple-line-icons",
          ],
          urls: ["<?php echo e(asset('assets/admin/css/fonts.min.css')); ?>"],
        },
        active: function () {
          sessionStorage.fonts = true;
        },
      });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/plugins.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/kaiadmin.min.css')); ?>" />


    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/demo.css')); ?>" />
    <style>
      .main-header .navbar-header {
            min-height: 45px;
        }
        .pl{
          padding-left:25px ;
        }
    </style>
    <?php echo $__env->yieldContent('style'); ?>
  </head>
  <body>
    <div class="wrapper">
      <!-- Sidebar -->
        <?php echo $__env->yieldContent('pageside'); ?>
        
      <!-- End Sidebar -->

      <div class="main-panel">


        <!-- main content header section start... -->
            <?php echo $__env->make('admin.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- main content header section end... -->

        
        <?php echo $__env->yieldContent('bodyContent'); ?>
        

        <!-- main content footer is start  -->
                <?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- main content footer is end  -->


      </div>

      
    </div>
    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('assets/admin/js/core/jquery-3.7.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/core/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/core/bootstrap.min.js')); ?>"></script>

    <!-- jQuery Scrollbar -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js')); ?>"></script>

    <!-- Chart JS -->
    <!-- <script src="<?php echo e(asset('assets/admin/js/plugin/chart.js/chart.min.js')); ?>"></script> -->

    <!-- jQuery Sparkline -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/jquery.sparkline/jquery.sparkline.min.js')); ?>"></script>



    <!-- Bootstrap Notify -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/bootstrap-notify/bootstrap-notify.min.js')); ?>"></script>



    <!-- Sweet Alert -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/sweetalert/sweetalert.min.js')); ?>"></script>

    <!-- Kaiadmin JS -->
    <script src="<?php echo e(asset('assets/admin/js/kaiadmin.min.js')); ?>"></script>

    <!-- Kaiadmin DEMO methods, don't include it in your project! -->
    <script src="<?php echo e(asset('assets/admin/js/setting-demo.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/demo.js')); ?>"></script>

     <?php if(session()->exists('success') || session()->exists('info') || session()->exists('warning') || session()->exists('danger')): ?>

     <script>

      //Notify

      let message = <?php echo json_encode(session('success') ?? session('info') ?? session('warning') ?? session('danger'), 15, 512) ?>;
      let type = '<?php echo e(session()->has('success') ? 'success' : (session()->has('info') ? 'info' : (session()->has('danger') ? 'danger' : 'warning'))); ?>';
      let iconClass = {
        success: 'fa fa-check-circle',
        info: 'fa fa-info-circle',
        warning: 'fa fa-exclamation-triangle',
        danger: 'fa fa-times-circle'
    };
    
      
      $.notify({
        icon: iconClass[type],
        message
      },{
        type,
        placement: {
          from: "top",
          align: "right"
        },
        time: 1000,
      });

    </script>

      <?php endif; ?>
   
    
    <?php echo $__env->yieldPushContent('script'); ?>
  </body>
</html>
<?php /**PATH D:\Corporate_website\linkup_bdColour\resources\views/admin/layout/app.blade.php ENDPATH**/ ?>