<footer id="footer" class="footer" style="background: #98dee1">

    <div class="container footer-top">
      <div class="row gy-4">
        <div class="col-lg-4 col-md-6 footer-about">
          <a href="index.html" class="logo d-flex align-items-center">
            <span class="sitename"><?php echo e($company->name?? "Company"); ?></span>
          </a>
          <div class="footer-contact pt-3">
            <p style="color: #0e0101c2!important;"><?php echo e($company->address ?? "address will be hare"); ?></p>
            
            <p class="mt-3"><strong>Phone:</strong> <span style="color: #0e0101c2!important;"><?php echo e($company->phone ?? '+8801xxxxxxxxxxx'); ?></span></p>
            <p><strong>Email:</strong> <span style="color: #0e0101c2!important;"><?php echo e($company->email ?? "demo@gmail.com"); ?></span></p>
          </div>
          <div class="social-links d-flex mt-4">
            <a href="<?php echo e($company->whatsapp ?? '#'); ?>"><i class="bi bi-whatsapp"></i></a>
            <a href="<?php echo e($company->facebook ?? '#'); ?>"><i class="bi bi-facebook"></i></a>
            <a href="<?php echo e($company->instagram ?? '#'); ?>"><i class="bi bi-instagram"></i></a>
            <a href="<?php echo e($company->linkdin ?? '#'); ?>"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-md-3 footer-links">
          <h4>Home Section</h4>
          <ul>
            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('home')); ?>#about">About us</a></li>
            <li><a href="<?php echo e(route('home')); ?>#service">Product</a></li>
            <li><a href="<?php echo e(route('home')); ?>#management">Management</a></li>
            <li><a href="<?php echo e(route('home')); ?>#gallery">Gallery</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-3 footer-links">
          <h4>Pages</h4>
          <ul>
            <li><a href="<?php echo e(route('delearlist')); ?>">Dealer List</a></li>
            <li><a href="<?php echo e(route('delearform')); ?>">Request Form</a></li>
            <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
            
          </ul>
        </div>

        <div class="col-lg-2 col-md-3 footer-links">
          <h4>Our Vision</h4>
          <div style="color: #0e0101c2!important;">
            <?php echo e(($company) ? substr($company->footer_text,0,170) : "company footer"); ?>

          </div>
        </div>
      </div>
    </div>

    <div class="container-fluid d-flex justify-content-center mt-4" style="background:#1cadb3b8;color:#fff">
      <p class="pt-3">© <span>Copyright</span> <strong class="px-1 sitename"><?php echo e($company->name); ?></strong> <span>All Rights Reserved</span></p>
     
    </div>

  </footer><?php /**PATH D:\Corporate_website\linkup_bdColour\resources\views/user/layout/footer.blade.php ENDPATH**/ ?>