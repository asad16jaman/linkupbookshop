<div class="sidebar" data-background-color="dark">
        <div class="sidebar-logo">
          <!-- Logo Header -->
          <div class="logo-header" data-background-color="" style="background:#6861ce;">
            <a href="<?php echo e(route('admin')); ?>" class="logo">
              <img
                src="<?php echo e($company ? asset('storage/'.$company->logo) : asset('assets/admin/img/demoProfile.png')); ?>"
                alt="navbar brand"
                class="navbar-brand"
                height="60px"
                width="60px"
                
              />
              <!-- <span style="color:#fff;font-size:10px"></span> -->
            </a>
            <div class="nav-toggle">
              <button class="btn btn-toggle toggle-sidebar">
                <i class="gg-menu-right"></i>
              </button>
              <button class="btn btn-toggle sidenav-toggler">
                <i class="gg-menu-left"></i>
              </button>
            </div>
            <button class="topbar-toggler more">
              <i class="gg-more-vertical-alt"></i>
            </button>
          </div>
          <!-- End Logo Header -->
        </div>
        <div class="sidebar-wrapper scrollbar scrollbar-inner">
          <div class="sidebar-content">
            <ul class="nav nav-secondary">

                <li class="nav-item <?php echo e(($page=='home') ? 'active' : ''); ?>">
                <a href="/admin">
                  <i class="fas fa-home"></i>
                   <p>Dashboard</p>
                </a>
              </li>
              <li class="nav-item <?php echo e(($page == 'slider' || $page == 'management' || $page == 'users' || $page == 'client') ? 'active' : ""); ?>">
                <a data-bs-toggle="collapse" href="#web">
                  <i class="fas fa-globe"></i> 
                  <p>Web Content</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="web">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="<?php echo e(route('admin.slider')); ?>" style="padding: 5px 24px !important">
                        
                        <p class="<?php echo e(($page == 'slider') ? 'sub-item' : 'pl'); ?>">Slider</p>
                      
                      </a>
                    </li>

                    <li>
                      <a href="<?php echo e(route('admin.management')); ?>" style="padding: 5px 24px !important">
                      
                        <p class="<?php echo e(($page == 'management') ? 'sub-item' : "pl"); ?>">Management</p>
                      </a>
                    </li>
                    <li>
                      <a href="<?php echo e(route('admin.client')); ?>" style="padding: 5px 24px !important">
                      
                        <p class="<?php echo e(($page == 'client') ? 'sub-item' : "pl"); ?>">Client</p>
                      </a>
                    </li>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny' ,Auth()->user())): ?> 
                    <li class="" >
                      <a href="<?php echo e(route('admin.users')); ?>" style="padding: 5px 24px !important">
                       
                        <p class="<?php echo e(($page == 'users') ? 'sub-item' : "pl"); ?>">Users</p>
                        
                      </a>
                    </li>
                    <?php endif; ?>
                  </ul>
                </div>
              </li>

              <li class="nav-item <?php echo e(($page == 'product' || $page == 'category') ? 'active' : ""); ?>">
                <a data-bs-toggle="collapse" href="#productss">
                  <i class="fas fa-project-diagram"></i>
                  <p>Product</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="productss">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="<?php echo e(route('admin.category')); ?>" style="padding: 0px 24px !important">
                       
                        <p class="<?php echo e(($page == 'category') ? 'sub-item' : 'pl'); ?>">Category</p>
                      
                      </a>
                    </li>

                    <li>
                      <a href="<?php echo e(route('admin.product')); ?>" style="padding: 5px 24px !important">
                        
                        <p class="<?php echo e(($page == 'product') ? 'sub-item' : 'pl'); ?>">Product</p>
                      
                      </a>
                    </li>
                    <!-- <li>
                      <a href="">
                        <span class="sub-item">Video Gallery</span>
                      </a>
                    </li> -->
                  </ul>
                </div>
              </li>
              
              <li class="nav-item <?php echo e(($page == 'gallery') ? 'active' : ""); ?>">
                <a data-bs-toggle="collapse" href="#sidebarLayouts">
                  <i class="fas fa-images"></i>
                  <p>Gallery</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="sidebarLayouts">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="<?php echo e(route('admin.photogallery')); ?>" style="padding: 5px 24px !important">
                        <span class="<?php echo e(($page == 'gallery') ? 'sub-item' : 'pl'); ?>">Photo Gallery</span>
                      </a>
                    </li>
                    <!-- <li>
                      <a href="">
                        <span class="sub-item">Video Gallery</span>
                      </a>
                    </li> -->
                  </ul>
                </div>
              </li>
              
              <li class="nav-item <?php echo e(($page=='area') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.area')); ?>">
                  <i class="fas fa-map"></i> 
                  <p>Area</p>
                  <!-- <span class="badge badge-success">4</span> -->
                </a>
              </li>


              <li class="nav-item <?php echo e(($page=='approve' || $page=='pending') ? 'active' : ''); ?>">
                <a data-bs-toggle="collapse" href="#dealers">
                  <i class="fas fa-handshake"></i>
                  <p>Dealers</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="dealers">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="<?php echo e(route('admin.delear')); ?>" style="padding: 5px 24px !important">
                        <span class="<?php echo e(($page=='approve') ? 'sub-item' : 'pl'); ?>">Approve Dealers</span>
                      </a>
                    </li>
                    <li>
                      <a href="<?php echo e(route('admin.p_delear')); ?>" style="padding: 5px 24px !important">
                        <span class="<?php echo e(($page=='pending') ? 'sub-item' : 'pl'); ?>">Pending Dealers</span>
                      </a>
                    </li>
                    
                  </ul>
                </div>
              </li>

             

              
              
              <li class="nav-item <?php echo e(($page=='company') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.company')); ?>">
                  <i class="fas fa-building"></i>
                  <p>Company</p>
                  
                </a>
              </li>

              <li class="nav-item <?php echo e(($page=='about') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.about')); ?>">
                  <i class="fas fa-info-circle"></i>
                  <p>About Us</p>
                </a>
              </li>
              <li class="nav-item <?php echo e(($page=='faq') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.faq')); ?>">
                  <i class="fas fa-question-circle"></i> 
                  <p>Faq</p>
                </a>
              </li>
              <li class="nav-item <?php echo e(($page=='contact') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.message')); ?>">
                  <i class="fas fa-envelope"></i>
                  <p>Contact</p>
                </a>
              </li>
              
            </ul>
          </div>
        </div>
      </div><?php /**PATH C:\Users\Link-Up Technology\Desktop\linkup_bdColour\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>