<?php $__env->startSection('title'); ?>
     home page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<style>
     /* .contact-from{
          background-color: var(--surface-color);
          box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
          height: 100%;
          padding: 30px;
     } */

      .bg-breadcrumb {
        position: relative;
        overflow: hidden;
        background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(<?php echo e(asset('assets/user/img/carousel-1.jpg')); ?>);
        background-position: center center;
        background-repeat: no-repeat;
        background-size: cover;
        padding: 20px 0 27px 0;
    }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagenave'); ?>
     <?php echo $__env->make('user.layout.navbar',['page'=>'contact'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<main class="main">
    <div class="container-fluid bg-breadcrumb">
            <div class="bg-breadcrumb-single"></div>
            <div class="container text-center py-3" style="max-width: 900px;">
                <h1 class="text-white  mb-4 wow fadeInDown" data-wow-delay="0.1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInDown;">Product</h1>
                <ol class="breadcrumb justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInDown;">
                    <li class="breadcrumb-item text-white"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    
                    <li class="breadcrumb-item active text-primary">Product</li>
                </ol>    
            </div>
    </div>
    

     <!-- Service Details Section -->
    <section id="service-details" class="service-details section">

      <div class="container">

        <div class="row gy-4">

          

          <div class="col-lg-8" data-aos="fade-up" data-aos-delay="200">
            <div><img style="width:736px;height:500;object-fit:cover" src="<?php echo e($product->picture ?  asset('storage/'.$product->picture) : asset('assets/user/img/services.jpg')); ?>" alt="" class="img-fluid services-img"></div>
            <div>
                <h3>Product Detail</h3>
                <?php echo $product->logn_description; ?>

            </div>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="services-list">
              <a href="#" class="active">Product : <?php echo e($product->name); ?></a>
              <a href="#">Category :<?php echo e($product->category->name); ?></a>
              <a href="#">Price :<?php echo e($product->price); ?></a>
            </div>

            
            <p>
                <h4>Detail Summary : </h4>
                <p><?php echo e($product->description); ?></p>
            </p>
          </div>

        </div>

      </div>

    </section><!-- /Service Details Section -->
      

   

    



  </main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Link-Up Technology\Desktop\linkup_bdColour\resources\views/user/singleproduct.blade.php ENDPATH**/ ?>