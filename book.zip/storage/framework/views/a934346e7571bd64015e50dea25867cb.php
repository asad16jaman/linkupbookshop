<header id="header" class="header sticky-top">

        <div class="topbar d-flex align-items-center">
            <div class="container d-flex justify-content-center justify-content-md-between">
                <div class="d-none d-md-flex align-items-center">
                    <i class="bi bi-clock me-1"></i>Saturday - Thursday, 8AM to 10PM
                </div>
                <div class="d-flex align-items-center">
                    <i class="bi bi-phone me-1"></i> Call us now <?php echo e($company->phone ?? '+88xxxxxxxxx'); ?>

                </div>
            </div>
        </div><!-- End Top Bar -->

        <div class="branding d-flex align-items-center">

            <div class="container position-relative d-flex align-items-center justify-content-end">
                <a href="<?php echo e(route('home')); ?>" class="logo d-flex align-items-center me-auto">
                    <img src="<?php echo e(($company && $company->logo) ? asset('storage/'.$company->logo) : asset('assets/user/img/logo.png')); ?>" alt="">
                  
                    <!-- Uncomment the line below if you also wish to use a text logo -->
                    <h1 class="sitename" id="typing-animation"></h1> 
                    <!-- Element to contain animated typing -->
								

								<script>

									// Initialize the typing animation
									let typingAnimationElement2 = document.getElementById('typing-animation');

                                    let company = "<?php echo e($company->name ?? 'company Name'); ?>"
									// Create an array of typing text
									let typingTexts = [
										company
									];

									// Create a function to display the typing animation for a given text
									function playTypingAnimation(text) {
										// Loop through each character and add it to the element
										for (let i = 0; i < text.length; i++) {
											setTimeout(() => {
												typingAnimationElement2.textContent += text[i];
											}, i * 200); // Increase the delay to slow down the typing animation
										}

										// Once the animation is complete, reset the text and start over
										setTimeout(() => {
											typingAnimationElement2.textContent = '';
											playTypingAnimation(typingTexts[(typingTexts.indexOf(text) + 1) % typingTexts.length]);
										}, text.length * 200);
									}

									// Start the typing animation loop
									playTypingAnimation(typingTexts[0]);

								</script>

								<br>
								<br>
                </a>

                <nav id="navmenu" class="navmenu">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>#hero">Home</a></li>
                        <li><a href="<?php echo e(route('home')); ?>#about" class="<?php echo e(($page == 'aboutdetail') ? 'active' : ''); ?>">About</a></li>
                        <li><a href="<?php echo e(route('home')); ?>#product">Product</a></li>
                        <li><a href="<?php echo e(route('home')); ?>#management">Management</a></li>
                        <li><a href="<?php echo e(route('home')); ?>#gallery">Gallery</a></li>
                        
                        <li><a href="<?php echo e(route('delearlist')); ?>" class="<?php echo e(($page && $page=='dealerlist') ? 'active' : ''); ?>">Dealerlist</a></li>

                        <li><a href="<?php echo e(route('delearform')); ?>" class="<?php echo e(($page && $page=='dealerform') ? 'active' : ''); ?>">Dealer Form</a></li>
                         <li><a href="<?php echo e(route('contact')); ?>" style="background:#3fbbc0;color:#fff;padding: 8px 13px;font-weight: 500;">Contact Us</a></li>
                        <!-- <li><a href="#contact"></a></li> -->
                         <!-- <li class=""><a class="cta-btn me-3 overflow-hidden" style="display: inline-block;width:100%;text-center" href="">Contact Us</a></li> -->
                    </ul>
                    <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
                </nav>

                

            </div>

        </div>

    </header><?php /**PATH D:\Corporate_website\linkup_bdColour\resources\views/user/layout/navbar.blade.php ENDPATH**/ ?>