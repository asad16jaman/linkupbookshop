<?php $__env->startSection('title'); ?>
     home page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
     <style>
           .hero .container {
                 background-color: #ffffff8f;
           }

           .gallery .swiper-slide-active {
                 background: var(--background-color) !important;
           }
           .section{
                padding: 30px 0!important;
           }
     </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagenave'); ?>
     <?php echo $__env->make('user.layout.navbar', ['page' => 'home'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


     <main class="main">

           <!-- hero section start hare  -->
           <?php echo $__env->make('user.home.carousel', compact(['carousels']), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
           <!-- hero section end hare  -->

           <!-- service category section start hare  -->
           <h2 class="text-center mt-4" style="font-size: 32px;font-weight: 700;">Categories<br></h2>
           <section id="featured-services" class="featured-services section" style="padding: ;">
                 <div class="container">
                       <div class="swiper mySwiper">
                              <div class="swiper-wrapper">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <div class="swiper-slide">
                                                         <div class="service-item position-relative"
                                                                 style="padding:0px;margin:0px;border:3px solid #3fbbc0;min-height:322px!important">
                                                                 <div class="bg-dark">
                                                                         <img src="<?php echo e(($category->img) ? asset('storage/' . $category->img) : asset('assets/user/img/cat2.jpg')); ?>"
                                                                                 alt="" class="img-fluid" width="100%">
                                                                 </div>
                                                                 <div class="p-3">
                                                                         <h4><a type="p" class="stretched-link"><?php echo e(\Illuminate\Support\Str::limit($category->name, 15)); ?></a></h4>
                                                                         <p><?php echo e(\Illuminate\Support\Str::limit($category->description, 100)); ?></p>
                                                                 </div>
                                                         </div>
                                                  </div>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                       </div>
                 </div>
           </section>

           <!-- service category section start hare  -->

           <!-- About Section -->
           <?php echo $__env->make('user.home.about', compact(['about']), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
           <!-- About Section -->

           <!-- Call To Action Section  -->
           <?php echo $__env->make('user.home.call_action', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
           <!-- Call To Action Section -->

           <!-- Product Section section start hare  -->
               <!-- include('user.home.service2', ['products'=> $products , 'frompage'=>'home']) -->
 
           <div class="section" id="product">
                       <h2 class="text-center " style="font-size: 32px;font-weight: 700;">Product<br></h2>
                       <section id="featured-services" class="featured-services  doctors " style="padding-bottom:0px!important">
                              <div class="container ">
                                    <div class="swiper mySwiper">
                                          <div class="swiper-wrapper">
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                 <div class="swiper-slide">
                                                                         <div class=" position-relative"
                                                                                 style="padding:0px;margin:0px;border:1px solid #3fbbc0;min-height:322px!important">
                                                                                 <div class="bg-light">
                                                                                        <img src="<?php echo e(($product->picture) ? asset('storage/' . $product->picture) : asset('assets/user/img/cat2.jpg')); ?>"
                                                                                                alt="" class="img-fluid"
                                                                                                style="width: 100%; height: 210px; object-fit: cover">
                                                                                 </div>
                                                                                 <div class="p-3">
                                                                                        <h4><?php echo e(\Illuminate\Support\Str::limit($product->name, 15)); ?></h4>
                                                                                        <p><?php echo e(\Illuminate\Support\Str::limit($product->description, 70)); ?></p>
                                                                                        <a href="<?php echo e(route('product.item',['id'=>$product->id])); ?>" style="background-color: #3fbbc0;font-size:14px;padding:5px 7px;color:#fff;" class="btn" >See Detail</a>
                                                                                 </div>
                                                                         </div>
                                                                 </div>
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </div>
                                    </div>
                                    <div class="row mt-5">
                                    <div class="col-12 d-flex justify-content-center">
                                          <a href="<?php echo e(route('product')); ?>" class="cta-btn" style="background: #3fbbc0;color: #fff ; padding: 10px 26px;border-radius: 10px;">See More</a>
                                    </div>
                                    </div>
                              </div>
                       </section>
                 </div>
          <!-- Product Section section start hare  -->

                 <!-- Management Section -->
                 <div id="management">
                  <div class="light-background section">
                       <h2 class="text-center " style="font-size: 32px;font-weight: 700;">Management<br></h2>
                       <div class="light-background">
                        <section id="featured-services " class="featured-services  doctors " style="background:#e5eded!important">
                              <div class="container">
                                    <div class="swiper mySwiper">
                                          <div class="swiper-wrapper">
                                                <?php $__currentLoopData = $managements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $management): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                 <div class="swiper-slide">
                                                                         <div class="service-item position-relative"
                                                                                 style="padding:0px;margin:0px;border:1px solid #3fbbc0;min-height:322px!important">
                                                                                 <div class="bg-light">
                                                                                        <img src="<?php echo e(($management->photo) ? asset('storage/' . $management->photo) : asset('assets/user/img/cat2.jpg')); ?>"
                                                                                                alt="" class="img-fluid"
                                                                                                style="width: 100%; height: 210px; object-fit: contain">
                                                                                 </div>
                                                                                 <div class="p-3">
                                                                                        <h4 class="text-center"><a href=""
                                                                                                         class="stretched-link"><?php echo e($management->name); ?></a></h4>
                                                                                        <p class="text-center"><?php echo e($management->designation); ?></p>
                                                                                 </div>
                                                                         </div>
                                                                 </div>
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </div>
                                    </div>
                              </div>
                       </section>
                       </div>
                 </div>
                 </div>
                 <!-- managemen section start hare  -->

                  <!-- client section start -->
                        <div class="container-fluid py-4">
                              <div class="container section-title" data-aos="fade-up" style="margin-bottom:0px!important;padding-bottom:0px">
                                    <h2>Clients</h2>
                                    </div><!-- End Section Title -->
                              <div class="swiper clientSwiper">
                                    <div class="swiper-wrapper">
                                          <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="swiper-slide">
                                                <div class="card">
                                                      <div class="card-body" style="display:flex;justify-content:center">
                                                           <img src="<?php echo e(asset('storage/'.$client->img)); ?>" class="img-fluid" style="height: 100px!important" alt="">
                                                      </div>
                                                </div>
                                                </div>
                                          
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          
                                         
                                    </div>
                              </div>
                        </div>
                  <!-- client section end -->



                 <!-- Gallery section start hare  -->
                 <?php echo $__env->make('user.home.gallery', compact(['gallery']), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                 <!-- testimonial section start hare  -->

     </main>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
     <script>
           var swiper = new Swiper(".mySwiper", {
                 slidesPerView: 1,
                 spaceBetween: 10,
                 loop: true,
                 autoplay: {
                       delay: 2500,
                       disableOnInteraction: false,
                 },
                 breakpoints: {
                       640: {
                              slidesPerView: 1,
                              spaceBetween: 10,
                       },
                       768: {
                              slidesPerView: 2,
                              spaceBetween: 15,
                       },
                       1024: {
                              slidesPerView: 3,
                              spaceBetween: 20,
                       },
                       1200: {
                              slidesPerView: 4,
                              spaceBetween: 20,
                       },
                 },
           });


           var swiper = new Swiper(".clientSwiper", {
                 slidesPerView: 1,
                 spaceBetween: 10,
                 loop: true,
                 
                  speed: 2200,
                 autoplay: {
                       delay: 100,
                       disableOnInteraction: false,
                 },
                 breakpoints: {
                       640: {
                              slidesPerView: 2,
                              spaceBetween: 10,
                       },
                       768: {
                              slidesPerView: 3,
                              spaceBetween: 15,
                       },
                       1024: {
                              slidesPerView: 4,
                              spaceBetween: 20,
                       },
                       1200: {
                              slidesPerView: 5,
                              spaceBetween: 20,
                       },
                 },
           });

     </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Corporate_website\linkup_bdColour\resources\views/user/home.blade.php ENDPATH**/ ?>