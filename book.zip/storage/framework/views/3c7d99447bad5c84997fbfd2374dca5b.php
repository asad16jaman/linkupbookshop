<?php $__env->startSection('title', 'Admin Page'); ?>

<?php $__env->startSection('pageside'); ?>
  <?php echo $__env->make('admin.layout.sidebar',['page' => 'contact'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .table>tbody>tr>td {
            padding: 0px !important;
            margin-bottom: 2px;
        }

        .iconsize {
            font-size: 15px;
        }

        .profileImg {
            width: auto;
            height: 100px;
            object-fit: cover;
            border: 2px dashed #ccc;
            border-radius: 6px;
        }

        .tablepicture {
            width: 30px;
            height: 30px;
            object-fit: fill;
        }

        
        .headbg > tr > th{
        background-color: #3c5236;
        color: #fff;
        padding: 2px !important;
        margin-bottom: 2px;
    }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bodyContent'); ?>

    <div class="container">
        <div class="page-inner" style="padding:0px 10px!important">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header p-2">
                            <h5 class="card-title ">ALL Messages</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <div id="basic-datatables_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">

                                    <div class="row " style="min-height:350px">
                                        <div class="col-sm-12">
                                            <table id="basic-datatables"
                                                class="display table table-striped table-hover dataTable" role="grid"
                                                aria-describedby="basic-datatables_info">
                                                <thead class="headbg">
                                                    <tr role="row bg-dark">
                                                        <th style="width: 136.031px;">SL NO:</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Subject</th>
                                                        <th>Message</th>
                                                        <th>Date</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <tr role="row" class="odd">
                                                            <td class="sorting_1"><?php echo e($loop->iteration); ?></td>
                                                            <td><?php echo e($msg->name); ?></td>
                                                            <td><?php echo e($msg->email); ?></td>
                                                            <td><?php echo e($msg->subject); ?></td>
                                                            <td><?php echo e($msg->message); ?> </td>
                                                            <td><?php echo e($msg->created_at->format('d-m-Y h:ia')); ?></td>
                                                            <td class="d-flex justify-content-center">

                                                                <form
                                                                    action="<?php echo e(route('admin.message.delete', ['id' => $msg->id])); ?>"
                                                                    method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <!-- <input type="submit" value="Delete"> -->
                                                                    <button type="submit" class="btn btn-danger p-1"><i
                                                                            class="fas fa-trash-alt iconsize"></i></button>
                                                                </form>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <p>there is no Message</p>

                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12 d-flex justify-content-center">
                                            

                                            <?php if($message->previousPageUrl()): ?>
                                                <a href="<?php echo e($message->previousPageUrl()); ?>" class="btn btn-primary mx-2 p-1"><i class="fas fa-hand-point-left"></i></a>
                                            <?php endif; ?>

                                            <?php if($message->nextPageUrl()): ?>
                                                <a href="<?php echo e($message->nextPageUrl()); ?>" class="btn btn-primary p-1"><i class="fas fa-hand-point-right "></i></a>
                                            <?php endif; ?>
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

    <?php $__env->startPush('script'); ?>


    <?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Link-Up Technology\Desktop\linkup_bdColour\resources\views/admin/message.blade.php ENDPATH**/ ?>