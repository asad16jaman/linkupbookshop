<!-- Featured Services Section -->
    <!-- width:260px;height:150px;object-fit:cover -->
<!-- #3fbbc0 -->
    <section id="featured-services" class="featured-services section">

      <div class="container">

        <div class="row gy-4">

          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up">
            <div class="service-item position-relative" style="padding:0px;margin:0px;border:3px solid #3fbbc0">
              <div class="bg-dark">
                <!-- <i class="fas fa-heartbeat icon"></i> -->
                 <img src="<?php echo e(($category->img ) ? asset('storage/'.$category->img) : asset('assets/user/img/cat2.jpg')); ?>" alt="" style="" class="img-fluid" width="100%">
              </div>
              <div class="p-3 ">
                <h4 class=""><a href="" class="stretched-link"><?php echo e($category->name); ?></a></h4>
                <p class=""><?php echo e(substr($category->description,0,100)); ?></p>
              </div>
            </div>
          </div><!-- End Service Item -->
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          

          

          

          

         

          

        </div>

      </div>

    </section><!-- /Featured Services Section --><?php /**PATH C:\Users\Link-Up Technology\Desktop\linkup_bdColour\resources\views/user/home/service.blade.php ENDPATH**/ ?>