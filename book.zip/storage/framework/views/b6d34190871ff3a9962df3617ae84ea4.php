<?php $__env->startSection('title', 'Admin Page'); ?>

<?php $__env->startSection('style'); ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageside'); ?>
  <?php echo $__env->make('admin.layout.sidebar',['page' => 'error'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bodyContent'); ?>

    <div class="container">
        <div class="row mt-5">
            <div class="col-12 mt-5">
                <p class="text-center">There is problame. please try again. and contact with developer</p>
                <h1 class="text-danger text-center">404</h1>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

   
<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Link-Up Technology\Desktop\linkup_bdColour\resources\views/admin/404.blade.php ENDPATH**/ ?>